<?php 


class utilisateur
{
	public $Id;
	public $Nom;
	public $Prenom;
	public $Password;
	public $Mail;
	public $pp;
	public $Last_Connexion;

	public function __construct()
	{
		
	
	}


	public function login()
	{

	}
	public function logout()
	{

	}


}