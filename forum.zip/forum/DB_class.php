
<?php

class Bdd
{

	 public
      $serveur     = '',
      $bdd         = '',
      $identifiant = '',
      $connect     = '',
      $mdp         = '';
	
 	public function __construct($serveur, $bdd, $identifiant, $mdp) { 
        $this->serveur = $serveur;
        $this->bdd = $bdd;
        $this->identifiant = $identifiant;
        $this->mdp = $mdp;
    }

    public function PDOConnexion() {
       $this->connect = new PDO('mysql:host='.$this->serveur.'; dbname='.$this->bdd, $this->identifiant, $this->mdp);
    }

    public function connexion(){
    	return $this->connect;
    }

    public function ExecuteReq(){
      $pdo= $this->connect;
      $reponse = $pdo->prepare('SELECT * FROM utilisateur');
      $donnees=$reponse->execute();

      while ($donnees = $reponse->fetch(PDO::FETCH_ASSOC))
      {
        echo $donnees['nom']. '<br/>';
        echo $donnees['prenom']. '<br/>';
      }
    }
}
   
?>