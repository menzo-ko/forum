<?php



class post{

	public $Id;
	public $Title;
	public $Post_contains;


	public function edit_post()
	{

	}

	public function mod_post()
	{

	}

	public function delete_post()
	{

	}

}