<!DOCTYPE html>
<?php
include 'DB_class.php' ;

	$bdd = new Bdd('localhost', 'forum', 'root', '');
	$bdd->PDOConnexion();
	$db = $bdd->connexion();
	$bdd->ExecuteReq();
?>


<p>
	nom : <input type = "text" /> </br>
	mot de passe : <input type = "password" /> </br> 
	<input type = "submit" value ="se connecter"> 
</p>

<input type = "submit" value ="s'incrire">

</html>