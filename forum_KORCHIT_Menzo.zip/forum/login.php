<!DOCTYPE html>


<html>
  <form action="index.php" method="post">
    <p>
      nom<input type="text" name="nom" /></br>
      mdp<input type="password" name="mdp" /></br>
      <input type="submit" name="submit" value="Valider" />
    </p>
  </form>

  <div class="retour">
    <a href="/forum/index.php">Retour à la page d'accueil</a>
  </div>

</html>
