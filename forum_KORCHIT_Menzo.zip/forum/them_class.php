<?php

class theme
{
	public $Id;
	public $Nom_Theme;
	public $Last_Message;


	public function load_Theme()
	{

	}

	
}