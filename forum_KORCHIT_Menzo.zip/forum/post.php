<!DOCTYPE html>


<html>
  <form action="post.php" method="post">
    <p>
      Titre du poste<input type="text" name="titre" /></br>
      Contenu<input type="text" name="contenu" /></br>
      <input type="submit" name="sendpost" value="Valider" />
    </p>
  </form>

<?php
  include 'post_class.php';
  include 'DB_class.php' ;
  if (isset($_POST['sendpost']))
  {
    $post = new post();
    $post->edit_post($_POST['titre'], $_POST['contenu']);
  }
?>

  <div class="retour">
    <a href="/forum/index.php">Retour à la page d'accueil</a>
  </div>
</html>
