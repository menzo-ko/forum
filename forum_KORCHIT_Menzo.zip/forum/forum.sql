-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le :  Dim 15 déc. 2019 à 21:02
-- Version du serveur :  5.7.24
-- Version de PHP :  7.1.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `forum`
--

-- --------------------------------------------------------

--
-- Structure de la table `post`
--

DROP TABLE IF EXISTS `post`;
CREATE TABLE IF NOT EXISTS `post` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `titre` varchar(255) NOT NULL,
  `contenu` varchar(1023) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `post`
--

INSERT INTO `post` (`id`, `titre`, `contenu`) VALUES
(1, 'premier post', 'je suis le premier post de ce site web'),
(2, 'Je galère', 'Bonjour, ce post, si tout ce passe bien, est censé s\'affiché suite a la connexion d\'un utilisateur.'),
(3, 'Encore un post', 'Toujours dans la galÃ¨re, ce post sert une fois de plus a la vÃ©rification'),
(4, 'Encore un post', 'post test encore'),
(5, 'Encore un post', 'pourquoi sont ils spÃ©ciaux ces Ã© ? pourquoi ne sont ils pas dÃ©finit comme une lettre avec sa propre  identitÃ©.'),
(6, 'encore les caractÃ¨re spÃ©ciaux', 'pourquoi sont ils spÃ©ciaux ces Ã© ? pourquoi ne sont ils pas dÃ©finit comme une lettre avec sa propre  identitÃ©.'),
(7, 'spÃƒÂ©ciaux', 'toujours eux , ÃƒÂ© ÃƒÂ  ÃƒÂª ÃƒÂ»');

-- --------------------------------------------------------

--
-- Structure de la table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) NOT NULL,
  `prenom` varchar(255) NOT NULL,
  `mdp` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `user`
--

INSERT INTO `user` (`id`, `nom`, `prenom`, `mdp`, `email`) VALUES
(1, 'korchit', 'menzo', 'password', 'email@gmail.com'),
(2, 'boyer', 'gauthier', 'pass', 'mail@gmail.com'),
(3, 'dewulf', 'felix', 'felou', 'fel@gmail.com'),
(9, 'drap', 'tho', 'oeoelacitÃ©', 'mou@gmail.com'),
(5, 'beugnez', 'remi', 'fuckbibi', 'remrem@gmail.com'),
(6, 'bibi', 'threefin', 'bibinul', 'tkt@gmail.com'),
(7, 'ounga', 'ounga', 'izi', 'caramel@gmail.com'),
(10, 'delattre', 'mar', 'dmar', 'unmail@gmail.com'),
(11, 'ko', 'me', 'kome', 'kome@gmail.com');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
