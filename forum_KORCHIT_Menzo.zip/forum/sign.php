<!DOCTYPE html>

<html>
    <form action="sign.php" method="post">
        <p>
            nom<input type="text" name="nom" /></br>
            prenom<input type="text" name="prenom" /></br>
            mail<input type="text" name="mail" /></br>
            mdp<input type="password" name="mdp" /></br>
            <input type="submit" name="sign" value="Valider" />
        </p>
    </form>

<?php
    include 'user_class.php';
    include 'DB_class.php' ;
        if (isset($_POST['sign']))
	    {
		  $user= new utilisateur();
		  $user->signin($_POST['nom'], $_POST['prenom'], $_POST['mail'], $_POST['mdp']);
	    }
?>
    <div class="retour">
    	<a href="/forum/index.php">Retour à la page d'accueil</a>
    </div>
</html>
 

