<?php

class post{

	public $Id;
	public $titre;
	public $contenu;


	public function edit_post($titre,$contenu)
	{
		$this->contenu = $contenu;
        $this->titre = $titre;
        $bdd = new Bdd('localhost', 'forum', 'root', '');
        $bdd->AddPost( utf8_encode($titre), utf8_encode($contenu));
        echo "Post édité";
	}

	
	public function mod_post()
	{

	}

	public function delete_post()
	{

	}

}