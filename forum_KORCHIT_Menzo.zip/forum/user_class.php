<?php 

class utilisateur
{
	public $Nom;
	public $Prenom;
	public $Mdp;
	public $Mail;
   
	public function __construct()
	{
	     	
	}

	public function logout()
	{

	}

public function Login($Nom, $Mdp ){
	 $this->Nom = $Nom;
   $this->Mdp = $Mdp;
   $bdd = new Bdd('localhost', 'forum', 'root', '');
   $res = $bdd->LoadDataUser();
   $donnees = $res->fetch(PDO::FETCH_ASSOC);
   $login = 0;
     	
   do      
   {      
    if ($Nom == $donnees['nom'] and $Mdp == $donnees['mdp'])
    { 
      $login++;
      $tab_session = array('nom' => $donnees['nom'],
                            'prenom' => $donnees['prenom'],
                            'id' => $donnees['id'],
                            );
    }
  }
  while ($donnees = $res->fetch(PDO::FETCH_ASSOC));

  if($login == 0)
  {
     echo "connexion échoué - Veuillez réessayer";
  }
  else
  {
    echo "connexion établie ";
    echo 'Bonjour ' . $Nom;
    echo $tab_session['id'];
    return $tab_session;
  } 
}   

public function signin($Nom, $Mdp, $Mail, $Prenom ){
  $this->Nom = $Nom;
  $this->Mdp = $Mdp;
  $this->Mail = $Mail;
  $this->Prenom = $Prenom;
  $bdd = new Bdd('localhost', 'forum', 'root', '');
  $bdd->AddUser($Nom, $Prenom, $Mail, $Mdp);
  echo "utilisateur inscrit - Vous pouvez retourner à la page d'accueil.";
}    
}
    /*  while ($donnees = $reponse->fetch(PDO::FETCH_ASSOC))
      {
        echo $donnees['nom']. '<br/>';
        echo $donnees['prenom']. '<br/>';
      }

*/
?>  