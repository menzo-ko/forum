 <?php

class Bdd
{ 
	 public
      $serveur     = '',
      $bdd         = '',
      $identifiant = '',
      $connect     = '',
      $mdp         = '';
	
 	  public function __construct($serveur, $bdd, $identifiant, $mdp) { 
        $this->serveur = 'localhost';
        $this->bdd = 'forum';
        $this->identifiant = 'root';
        $this->mdp = '';
        $this->connect = new PDO('mysql:host='.$this->serveur.'; dbname='.$this->bdd, $this->identifiant, $this->mdp);
    }

    public function connexion(){
    	return $this->connect;
    }


    public function LoadDataUser(){
      $pdo = $this->connect;
      $reponse = $pdo->prepare('SELECT * FROM user');  
      $reponse->execute();
      return $reponse;
    }

    public function LoadDataPost(){
      $pdo = $this->connect;
      $reponse = $pdo->prepare('SELECT * FROM post');  
      $reponse->execute();

       while ($donnees = $reponse->fetch(PDO::FETCH_ASSOC))
      {

        echo '<h2>' . utf8_encode($donnees['titre']). '</h2>' . '<br/>';
        echo '<p>' . utf8_encode($donnees['contenu']). '</p>' . '<br/>';
      }
      return $reponse;
    }

   public function AddUser($Nom, $Mdp, $Mail, $Prenom){
      $pdo = $this->connect;
      $reponse = $pdo->prepare("INSERT INTO  user (nom, prenom, mdp, email) VALUES ('$Nom','$Prenom' ,'$Mdp','$Mail') " );
      $reponse->execute();

   }

   public function AddPost($titre, $contenu){
      $pdo = $this->connect;
      $reponse = $pdo->prepare("INSERT INTO  post (titre, contenu) VALUES ('$titre' , '$contenu') " );
      $reponse->execute();



   }

}
   
?>