<!DOCTYPE html>

<html>
	<head>
		<meta charset="utf-8">
		<!--<link rel="stylesheet" href="/web/css/main.css" />-->
		<link rel="stylesheet" href="/forum/css/forum.css" />
	</head>
	<body id="index">
		<div class="page">
		<?php

			include 'DB_class.php' ;
			include 'user_class.php';

			session_start();

  			$bdd = new Bdd('localhost', 'forum', 'root', '');
  			$db = $bdd->connexion();

  			if (isset($_POST['submit']))
  			{ 	
    			$user= new utilisateur();
    			$_SESSION =  $user->Login($_POST['nom'], $_POST['mdp']);  	
			}

 			if (isset($_SESSION['id']))
 			{
 				echo 'Bonjour, vous etes connecté en tant que ' . $_SESSION['nom'] . ' ' . $_SESSION['prenom'];
 			}
		?>

			<!---------------------HEADER---------------------->
	<header>
		<div class="entete">
			<div class="Forum_img">
				<img class="photo" src="/forum/images/forum_img" alt="img_forum"/>
			</div>
	
			<div class="identification">
				<div class="inscription">
					<a href="/forum/sign.php">S'inscrire</a>
				</div>

				<div class="connexion">
					<a href="/forum/login.php">se connecter</a>
				</div>
			</div>
		</div>
	</header>
			<!--------------------section ------------>
			
	<section>
		<div>
		<?php
			if (!isset($_SESSION['id']))
			{
		?>
				<h1>POST</h1>
				<p>Bonjour, Veuillez-vous identifier ou vous inscrire afin d'accéder au post de ce forum</p>
		<?php
			}
			else
			{
		?>
				<h1>POST</h1>
					<p>Bonjour, Voici les posts</p>
				<div class="show_post">
		<?php
				 $post_rest = $bdd->LoadDataPost();

		?>
		
				</div>	
			
			<div class="add_post">
				<a href="/forum/post.php">Ajouter un post</a>
			</div>
		<?php
			}
		?>
		</div>				
	</section>
			<!---------------------FOOTER---------------------->
			<footer>		
			</footer>
		</div>
	</body>
</html>



